export const Themes = {
  LIGHT : 'light',
  DARK : 'dark'
};
