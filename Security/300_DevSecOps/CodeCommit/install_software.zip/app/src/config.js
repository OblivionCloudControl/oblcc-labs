export default {
  HEADER_TITLE : "SEC332 Web Application",
  HEADER_LOGO : "https://amazonwebservices.gallerycdn.vsassets.io/extensions/amazonwebservices/aws-vsts-tools/1.0.21/1521739315168/Microsoft.VisualStudio.Services.Icons.Default",
  ACCESS_KEY: 'AKIAIOSFODNN7EXAMPLE',
  SECRET_KEY: 'wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY'
};
